package schoolmanagement;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.border.LineBorder;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Dashboard1 extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Dashboard1 frame = new Dashboard1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Dashboard1() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 916, 619);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(89, 85, 98));
		contentPane.setBorder(new LineBorder(new Color(0, 0, 0), 3));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
	
			
		lblNewLabel.setFont(new Font("Perpetua Titling MT", Font.BOLD, 25));
		lblNewLabel.setBackground(new Color(125, 119, 136));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setIcon(new ImageIcon("D:\\Myfiles\\Downloads\\images (8).jpg"));
		lblNewLabel.setBounds(0, 0, 902, 572);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("USER");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				new StudentProfile().setVisible(true);
			}
		});
		btnNewButton.setBackground(new Color(155, 151, 164));
		btnNewButton.setFont(new Font("Perpetua Titling MT", Font.BOLD, 25));
		btnNewButton.setBounds(121, 82, 181, 52);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("ADMIN");
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				new Table().setVisible(true);
			}
		});
		btnNewButton_1.setBackground(new Color(155, 151, 164));
		btnNewButton_1.setFont(new Font("Perpetua Titling MT", Font.BOLD, 25));
		btnNewButton_1.setBounds(525, 82, 181, 52);
		contentPane.add(btnNewButton_1);
	}

}
