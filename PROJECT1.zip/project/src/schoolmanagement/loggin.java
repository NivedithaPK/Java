package schoolmanagement;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.DisplayMode;
import java.awt.Font;
import java.awt.Window;

import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.border.LineBorder;

public class loggin extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					loggin frame = new loggin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public loggin() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 902, 548);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(125, 119, 136));
		contentPane.setBorder(new LineBorder(new Color(0, 0, 0), 3));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBackground(new Color(121, 121, 121));
		lblNewLabel.setIcon(new ImageIcon("D:\\Myfiles\\Downloads\\th.jpg"));
		lblNewLabel.setBounds(0, 0, 888, 511);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("LOGIN");
		lblNewLabel_1.setFont(new Font("Calibri", Font.BOLD, 26));
		lblNewLabel_1.setBounds(618, 10, 218, 76);
		contentPane.add(lblNewLabel_1);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(517, 84, 305, 2);
		contentPane.add(separator);
		
		JLabel lblNewLabel_2 = new JLabel("USERNAME");
		lblNewLabel_2.setFont(new Font("Mongolian Baiti", Font.BOLD | Font.ITALIC, 17));
		lblNewLabel_2.setBounds(539, 173, 102, 13);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("PASSWORD");
		lblNewLabel_3.setFont(new Font("Mongolian Baiti", Font.BOLD | Font.ITALIC, 17));
		lblNewLabel_3.setBounds(539, 247, 102, 13);
		contentPane.add(lblNewLabel_3);
		
		textField = new JTextField();
		textField.setBounds(690, 171, 132, 19);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(517, 351, 319, 2);
		contentPane.add(separator_1);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(690, 245, 132, 19);
		contentPane.add(passwordField);
		
		JButton btnNewButton = new JButton("SUBMIT");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				try {

				System.out.println(textField.getText());

				System.out.println(passwordField.getText());

				Class.forName("oracle.jdbc.driver.OracleDriver");

				Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","msc","msc");

				Statement stmt=con.createStatement();

				String query="select * from login where u_name='"+textField.getText()+"' and pass='"+passwordField.getText()+"'";

				ResultSet rst=stmt.executeQuery(query);

				if (rst.next())

				{

				loggin loggin = new loggin();

				System.out.println("USER EXISTS");

				JOptionPane.showMessageDialog(null, "User Successfully LOgged in");

				new Dashboard1().setVisible(true);

				setVisible(false);

				}

				else

				{

				System.out.println("USER INVALID");

				JOptionPane.showMessageDialog(null,"User Invalid");

				loggin login12 = new loggin();

				login12.dispose();

				}

				rst.close();

				}

				catch (Exception q) {

				System .out.println(q);

				}

				}

				});
				
		btnNewButton.setFont(new Font("Mongolian Baiti", Font.BOLD, 15));
		btnNewButton.setBounds(627, 394, 102, 21);
		contentPane.add(btnNewButton);
			}
		}


